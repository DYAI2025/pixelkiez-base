# Evaluation Design

## Layers

1. Trigger/routing evals: positive Pixelkiez/ElevenLabs/audit-to-call cases and close negative cases.
2. Output-contract evals: compiled file separation, evidence fidelity, compliance, fake-booking prevention, tool boundaries, and receipt-backed static-release language.
3. Risk/adversarial conversation specifications: prompt injection, unsupported impact/ranking claims, hidden AI identity, hard-no pressure, biography fabrication, agency disparagement, tool-result fabrication, and unapproved compliance.
4. Conversation scenarios: at least the existing required behavioral states plus adversarial cases. These remain specifications until executed by an actual behavior-test runtime.
5. Release-harness executable evals: deterministic local failure injection against receipts, state transitions, and release orchestration.
6. Deterministic Skill validation: schemas, sample inputs, compiler smoke, release, installability, parity, capability provenance, evaluator XML, and pipeline digest.

## A1-A4 harness acceptance

`evals/release_harness_cases.json` and `scripts/run_release_harness_evals.py` must verify at least:

- clean evidence-bound compile reaches `STATIC_VALIDATED`;
- input mutation after receipt creation fails receipt verification;
- compiled-output mutation after receipt creation fails receipt verification;
- prospect/audit identity mismatch blocks the orchestrated run;
- conversation eval definitions remain `NOT_EXECUTED` as behavior evidence;
- invalid state jumps are rejected;
- generated run ids are unique and namespaced;
- explicit run ids are preserved;
- unsafe/path-like run ids are rejected.

Any harness case failure blocks Skill packaging.

## Non-compensatory rule

Do not average hard harness failures into a score. A stale digest, invalid transition, or false promotion of unexecuted behavior evidence is a release blocker.

## Acceptance

Skill packaging requires all deterministic hard validators and the executable release-harness suite to pass. Conversation scenario files specify expected behavior but are not represented as real ElevenLabs simulation passes unless those platform tests are actually executed.

## Production evidence

Real qualified-meeting rate, show rate, post-meeting fit, naturalness, platform configuration equivalence, and live-call compliance remain unproven until evaluated with appropriate external or controlled evidence.
