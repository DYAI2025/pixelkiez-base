# Evaluation Design

## Layers

1. Trigger/routing evals: positive Pixelkiez/ElevenLabs/audit-to-call cases and close negative cases.
2. Output-contract evals: compiled file separation, evidence fidelity, compliance, fake-booking prevention, tool boundaries.
3. Risk/adversarial evals: prompt injection, unsupported impact/ranking claims, hidden AI identity, hard-no pressure, biography fabrication, agency disparagement, tool-result fabrication, unapproved compliance.
4. Conversation scenarios: at least the 20 required behavioral states plus adversarial cases.
5. Deterministic validation: schemas, sample inputs, compiler smoke, release, installability, parity, capability provenance, evaluator XML, and pipeline digest.

## Acceptance

Skill packaging requires all deterministic hard validators to pass. Conversation scenario files specify expected behavior but are not represented as real ElevenLabs simulation passes unless those platform tests are actually executed.

## Production evidence

Real qualified-meeting rate, show rate, post-meeting fit, and naturalness remain unproven until evaluated with real or controlled call data.
