# Agent-Agnostic Compatibility

Core workflow is expressed in portable Markdown, JSON Schema, JSON/JSONL, YAML, DOT, and Python. `agents/openai.yaml` is ChatGPT/OpenAI-specific metadata; the method itself is not.

Portable: source/claim policy, domain schemas, compiler logic, validators, eval cases, A1-A4 receipt/state logic, and release concepts.

Not guaranteed across runtimes: local Python or jsonschema execution, filesystem access, connector permissions, browser/network access, nested skill invocation, voice/telephony APIs, or installation UI. Without local code execution, receipt-backed STATIC_VALIDATED must be reported as runtime-unavailable rather than inferred.

Claude/Codex/Cursor/Windsurf-style handoff: load `SKILL.md` as control plane, then references only as needed; run Python validators locally when permitted. This is semantic portability, not identical runtime behavior.
