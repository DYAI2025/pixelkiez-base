# Agent-Agnostic Compatibility

Core workflow is expressed in portable Markdown, JSON Schema, JSON/JSONL, YAML, DOT, and Python. `agents/openai.yaml` is ChatGPT/OpenAI-specific metadata; the method itself is not.

Portable: source/claim policy, domain schemas, compiler logic, validators, eval cases, state machine, and release concepts.

Not guaranteed across runtimes: tool availability, filesystem access, connector permissions, browser/network access, nested skill invocation, voice/telephony APIs, or installation UI.

Claude/Codex/Cursor/Windsurf-style handoff: load `SKILL.md` as control plane, then references only as needed; run Python validators locally when permitted. This is semantic portability, not identical runtime behavior.
