# Source Map

Each record includes `type:`, `purpose:`, `reliability:`, `limitations:`, and `confidence_default:` for deterministic source-discipline validation.

## S001 — Build contract supplied in current conversation
- type: `user_provided`
- location: current uploaded build instruction, 2026-08-26
- purpose: Canonical project requirements, target architecture, non-goals, release blockers, and output contract.
- reliability: Authoritative for project design decisions.
- limitations: Does not prove external platform behavior, legal eligibility, or current public facts.
- confidence_default: 5 for internal requirements; 2 for embedded external claims until verified.

## S002 — Pixelkiez public website
- type: `primary`
- location: https://pixelkiez.de/en/
- verified_at: 2026-08-26
- purpose: Current public Pixelkiez positioning, services, website jobs, process, price-entry points, and portfolio exclusions.
- reliability: First-party public source.
- limitations: Public site does not prove internal sales process, scorecard approval, named consultant, or outbound policy.
- confidence_default: 5 for directly observed public claims.

## S003 — ElevenLabs Dynamic Variables / Personalization
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/personalization/dynamic-variables
- verified_at: 2026-08-26
- purpose: Runtime variables in prompts, first messages, and tools.
- reliability: Official current product documentation.
- limitations: Product behavior can change; re-verify before production integration.
- confidence_default: 5.

## S004 — ElevenLabs System Tools
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/tools/system-tools
- verified_at: 2026-08-26
- purpose: State update and system-tool model.
- reliability: Official current product documentation.
- limitations: Exact availability may depend on channel/configuration.
- confidence_default: 5.

## S005 — ElevenLabs End Call
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/tools/system-tools/end-call
- verified_at: 2026-08-26
- purpose: Verified end-call system tool behavior.
- reliability: Official current product documentation.
- limitations: API-created agents require explicit configuration per documentation.
- confidence_default: 5.

## S006 — ElevenLabs Voicemail Detection
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/tools/system-tools/voicemail-detection
- verified_at: 2026-08-26
- purpose: Verified voicemail detection capability.
- reliability: Official current product documentation.
- limitations: Live telephony behavior still requires deployment testing.
- confidence_default: 5.

## S007 — ElevenLabs Transfer to Number
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/tools/system-tools/transfer-to-number
- verified_at: 2026-08-26
- purpose: Verified phone transfer capability and channel boundary.
- reliability: Official current product documentation.
- limitations: Requires compatible telephony configuration; no Pixelkiez destination is approved here.
- confidence_default: 5.

## S008 — ElevenLabs Webhook Tools
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/tools/webhook-tools
- verified_at: 2026-08-26
- purpose: External API/tool contract capability.
- reliability: Official current product documentation.
- limitations: Does not prove any Pixelkiez calendar/CRM endpoint exists.
- confidence_default: 5.

## S009 — ElevenLabs Conversation Flow
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/conversation-flow
- verified_at: 2026-08-26
- purpose: Conversation duration, silence/turn timeout, interruptions, soft timeout, and turn behavior.
- reliability: Official current product documentation.
- limitations: Settings must be tuned/tested for the concrete use case.
- confidence_default: 5.

## S010 — ElevenLabs Agent Testing
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/agent-testing
- verified_at: 2026-08-26
- purpose: Simulation, next-reply, tool-call, mocking, and multi-run testing capabilities.
- reliability: Official current product documentation.
- limitations: Simulations do not prove real-call conversion or legal compliance.
- confidence_default: 5.

## S011 — ElevenLabs Knowledge Base
- type: `primary`
- location: https://elevenlabs.io/docs/eleven-agents/customization/knowledge-base
- verified_at: 2026-08-26
- purpose: Full-context and RAG knowledge modes.
- reliability: Official current product documentation.
- limitations: Retrieval correctness and latency require use-case evaluation.
- confidence_default: 5.

## S012 — German UWG § 7
- type: `primary`
- location: https://www.gesetze-im-internet.de/uwg_2004/__7.html
- verified_at: 2026-08-26
- purpose: Primary legal text relevant to unsolicited telephone advertising.
- reliability: Official German law publication.
- limitations: Does not by itself decide a concrete call's legality; factual/legal application requires qualified review.
- confidence_default: 5 for the text, not for case classification.

## S013 — EU AI Act Article 50 / Article 113
- type: `primary`
- location: https://eur-lex.europa.eu/eli/reg/2024/1689/oj/deu
- verified_at: 2026-08-26
- purpose: AI-interaction transparency and application timing.
- reliability: EUR-Lex primary legal source.
- limitations: Concrete deployment obligations require legal analysis and current consolidated text.
- confidence_default: 5 for the cited text, not for case classification.

## S014 — German StGB § 201
- type: `primary`
- location: https://www.gesetze-im-internet.de/stgb/__201.html
- verified_at: 2026-08-26
- purpose: Primary legal text relevant to recording non-public spoken words.
- reliability: Official German law publication.
- limitations: Does not automatically determine consent or recording setup legality.
- confidence_default: 5 for the text, not for case classification.

## MISSING project sources

The requested `skill_foundation_blueprint.md`, `analysis_report(8).json`, `analysis_report(8).md`, `gesamtkonzept_analyse_pixelkiez_adaptive_elevenla.md`, and `validation-output(3).txt` were not available in the accessible uploads/File Library for this build. They remain `MISSING`; no claim from them is treated as inspected.

`SOURCE_NEEDED`: final approved Pixelkiez score/audit standard, exact human meeting offer/consultant contract, production calendar/CRM integration, and deployment-specific legal approval.

## S015 - User-approved A1-A4 release-harness update
- type: `user_provided`
- location: current project conversation, 2026-08-26
- purpose: Requires Build Receipt, local Release Orchestrator, explicit State Machine, and executable Harness Evals around the Pixelkiez agent compiler while preserving the pure compiler and excluding live ElevenLabs integration from this slice.
- reliability: Authoritative for the requested internal architecture change.
- limitations: Does not prove that the new harness improves real call quality or that future ElevenLabs platform adapters will work.
- confidence_default: 5 for internal scope and Definition of Done; 2 for any external-effect claim not separately verified.
