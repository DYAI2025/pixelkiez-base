# ElevenLabs Runtime Contract

Verified against official ElevenLabs documentation on 2026-08-26. Re-verify before production deployment because platform behavior can change.

## ADOPTED capabilities

1. **System prompt and first message**: configurable agent behavior/message surfaces. Source S003/S011 and official quickstart.
2. **Dynamic Variables**: runtime values can be injected into prompts, first messages, and tools. Source S003. Preferred over full prompt replacement for structured personalization.
3. **State update system tool**: can update dynamic variables from conversation state. Source S004.
4. **End Call system tool**: verified; dashboard-created agents may include it by default, API/SDK-created agents require explicit configuration per docs. Source S005.
5. **Voicemail Detection system tool**: verified capability. Source S006. Production behavior requires telephony testing.
6. **Transfer to Number**: verified for phone calls with documented telephony boundaries; no Pixelkiez destination is approved here. Source S007.
7. **Webhook tools**: can connect to external APIs for reads/actions. Source S008. No calendar/CRM endpoint is assumed.
8. **Conversation Flow settings**: duration, silence/turn timeout, soft timeout, interruptions, and turn behavior are platform settings rather than system-prompt mechanics. Source S009.
9. **Agent Testing**: Simulation, Next Reply, and Tool Call testing are documented; simulation supports controlled tool mocking and multi-run pass rates. Source S010.
10. **Knowledge Base**: full-context and RAG modes are documented. Source S011.

## Architecture mapping

- Stable identity/mission/truth/claim/conversation/handoff/tool guardrails -> SYSTEM_PROMPT.
- Opening disclosure/permission -> FIRST_MESSAGE.
- Prospect/campaign/state values -> DYNAMIC VARIABLES.
- Validated audit findings -> AUDIT RUNTIME PACKET.
- Approved industry capsule -> INDUSTRY CONTEXT.
- Approved larger reference knowledge -> KNOWLEDGE BASE MANIFEST.
- End/voicemail/state/transfer candidates -> SYSTEM TOOLS, subject to channel/config approval.
- Calendar/CRM -> EXTERNAL TOOLS CONTRACT only; capability remains unverified until integrated.
- Timing/interruption/language/voice -> PLATFORM / CONVERSATION SETTINGS.
- Regression behavior -> EVALUATION.

## Not claimed

This package does not claim a Pixelkiez ElevenLabs account exists, that telephony is configured, that any tool is enabled, that a specific voice/number/LLM is approved, or that dashboard/API behavior will remain unchanged.
