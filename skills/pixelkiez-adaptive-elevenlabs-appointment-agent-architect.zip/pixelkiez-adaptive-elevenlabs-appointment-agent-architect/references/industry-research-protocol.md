# Industry Research Protocol

## Goal

Create an Industry Context Capsule that changes relevance and vocabulary without stereotyping people or inventing pains.

## Procedure

1. Define industry, subindustry, region, business model, customer groups, and buyer roles.
2. Identify website jobs and conversion paths relevant to the business model.
3. Identify trust signals and terminology from current reputable sources.
4. Mark regulated/sensitive topics.
5. Record observable market triggers separately from speculative pain points.
6. Convert research into the structured schema with source refs, confidence, and verification date.
7. Do not operationalize live-retrieved free text directly in the call.

## Boundaries

Industry adaptation may influence terminology, website-job relevance, explanation depth, buyer perspective, and conversion paths. It may not infer personality, communication preference, purchasing power, intelligence, or pain solely from industry/region.
