# Audit-to-Call Relevance and Hook Selection

## Default behavior

Use one primary finding hook, optionally a second. A third requires genuine prospect interest. Never read a full audit unprompted.

## Deterministic internal ranking

This is a DESIGN_DECISION, not an external standard. Each optional `hook_features` value is in 0..1.

`score = 0.35*evidence + 0.25*business_relevance + 0.15*phone_explainability + 0.15*actionability + 0.10*specificity - 0.15*sensitivity_risk - 0.10*technical_complexity`

Evidence mapping: VERIFIED_FACT=1.0, SUPPORTED_INFERENCE=0.65, HYPOTHESIS=0.30, UNKNOWN=0.0.

If optional features are absent, the compiler uses neutral 0.5 values rather than inventing certainty. UNKNOWN findings are never selected.

## Selection guardrails

Prefer strong evidence, direct observability, understandable phone wording, and a plausible question. Penalize sensitive or deeply technical issues. Do not infer economic loss from technical severity.
