# Research Bag

## Build recommendation

`proceed_with_assumptions` for the architecture skill; `BLOCKED_EXTERNAL` for live outbound production.

## Knowledge model

- Stable identity: Pixelkiez, current public website positioning, evidence-first diagnosis, human strategic handoff.
- Adaptive context: industry, business model, buyer role, website job, terminology, prospect, campaign, audit findings.
- Runtime separation: stable system policy vs dynamic variables vs audit packet vs industry capsule vs tools/settings.
- Compliance: externally provided, fail-closed.
- Meeting: relevance-triggered human handoff, not turn-count triggered.

## Capability candidates

Verified from primary ElevenLabs documentation: system prompt/first message configuration, Dynamic Variables, state updates, system tools, webhook tools, knowledge base, conversation-flow settings, automated Agent Testing, end call, voicemail detection, and transfer-to-number.

Not adopted as production integration: any concrete Pixelkiez calendar, CRM, dialer, phone number, transfer destination, recording workflow, or legal eligibility engine.

## Evaluation requirements

Trigger, output-contract, adversarial/risk, conversation-scenario, schema, compiler-smoke, capability-provenance, release, installability, core-parity, evaluator, and pipeline-digest checks are mandatory.
