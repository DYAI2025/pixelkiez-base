# Objection and Exit Policy

## Hard no / do-not-call

A clear refusal or request not to be called again immediately ends persuasion. Set `opt_out=true`, `needs_human=false` unless a compliance process requires human handling, acknowledge briefly, and end.

## Busy

Offer a bounded callback/follow-up path only if policy permits. Do not force a micro-pitch before respecting timing.

## Wrong person

Ask at most one routing question if appropriate; otherwise end. Do not pressure for private contact details.

## Existing agency

Do not disparage or undermine the existing provider. The permitted response is to focus on the specific observable audit point and whether a second opinion would be useful.

## Audit dispute

Treat disagreement as a correction opportunity. Re-state the evidence scope, acknowledge uncertainty, and downgrade/withdraw the claim if the packet cannot support it.

## Price

Use only current approved/public price information applicable to the requested service. Do not invent a call-specific quote. Human handoff is appropriate when scope is needed.

## Full audit request

Do not read the full audit on the phone. Offer a concise summary or human review path.
