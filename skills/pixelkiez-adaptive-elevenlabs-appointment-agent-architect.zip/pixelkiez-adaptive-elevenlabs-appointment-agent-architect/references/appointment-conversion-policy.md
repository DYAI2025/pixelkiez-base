# Appointment Conversion Policy

## Primary goal

`qualified_meeting_rate`, bounded by evidence fidelity and opt-out respect. Raw meeting count is not the primary objective.

## Meeting readiness signals

A meeting invitation is appropriate when at least one real signal exists, for example the prospect:

- confirms the audit topic is relevant;
- names a related website/business goal;
- asks for interpretation, prioritization, strategy, next steps, or deeper audit detail;
- describes uncertainty where human judgement would add value.

## Bridge

`customer goal + verified audit signal + AI limitation + value of human judgement -> qualified invitation`

## Quality metrics

Track when real data exists: qualified meeting rate, show rate, post-meeting fit, evidence fidelity, hard-no respected rate, opt-out rate, unsupported claim rate, audit-finding dispute rate, naturalness/responsiveness, and fake-booking rate.

Do not claim performance until real or controlled evaluation supports it.
