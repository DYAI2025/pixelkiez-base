# Buyer and Website Jobs Ontology

Use this as a mapping vocabulary, not a claim that every company has every job.

## Website jobs

- `discoverability`: be found for relevant brand/non-brand/local/AI-assisted discovery.
- `comprehension`: make offer, audience, differentiator, and next step understandable.
- `trust`: provide credible proof, current facts, people/process clarity, and risk reduction.
- `conversion`: provide a measurable enquiry, booking, application, or purchase path.
- `recruiting`: attract and convert relevant applicants.
- `service_efficiency`: reduce avoidable phone/admin friction where appropriate.
- `ownership_resilience`: reduce dependency on third-party platforms where relevant.

## Buyer roles

Roles are contextual variables such as owner/managing director, marketing lead, sales lead, recruiting/HR, operations, or technical/web owner. Do not assume authority from title alone; verify role relevance in conversation.

## Relevance mapping

Map `industry x business_model x website_job x buyer_role x audit_finding`. If any factor is unknown, ask rather than infer.
