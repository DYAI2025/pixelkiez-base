# Offline Agent Release Harness A1-A4

## Purpose

Use the release harness to prove the static build state of one compiled Pixelkiez agent without implying that conversation behavior, ElevenLabs platform behavior, tools, telephony, legal eligibility, or live calling were tested.

The harness wraps the existing pure compiler. It does not replace `compile_agent_package.py` and does not add network calls.

## Controlled states

The A1-A4 implementation permits only these transitions:

```text
INIT -> INPUTS_VALIDATED -> COMPILED -> STATIC_VALIDATED
  |           |                |               |
  +-----------+----------------+--------------> BLOCKED
```

A run that reaches `STATIC_VALIDATED` proves only:

- the three structured domain inputs passed their local validators;
- the compiler exited successfully;
- the compiled package passed `validate_agent_package.py`;
- the receipt binds those exact inputs, compiler bytes, and compiled output bytes by SHA-256;
- receipt validation detects later input, compiler, or output mutation.

It does not prove:

- conversation scenarios were executed against an LLM or ElevenLabs;
- a configured ElevenLabs agent or branch exists;
- calendar, CRM, transfer, telephony, or voicemail behavior works;
- a concrete lead may legally be called;
- real-call quality, conversion, show rate, or naturalness.

## Build receipt

`agent-build-receipt.json` binds:

- `run_id` and `build_id`;
- config, industry capsule, and audit packet SHA-256 values;
- compiler SHA-256;
- compiled output tree SHA-256 and file count;
- local validator/compiler execution results by exit code and stdout/stderr digests;
- eval-spec digests and case counts;
- scoped release claims.

The receipt deliberately records behavioral and platform validation as `NOT_EXECUTED`.

## Orchestrator

Prefer:

```bash
python scripts/run_agent_release.py \
  --config <agent-build-config.json> \
  --industry <industry-context.json> \
  --audit <website-audit-packet.json> \
  --out <compiled-agent-dir>
```

Use `--run-id` only when an external process supplies a stable non-secret identifier. Otherwise the orchestrator generates a fresh run id.

The default evidence directory is `<compiled-agent-dir>.evidence/<run-id>`.

## Receipt verification

Use:

```bash
python scripts/validate_agent_build_receipt.py \
  <agent-build-receipt.json> \
  --config <agent-build-config.json> \
  --industry <industry-context.json> \
  --audit <website-audit-packet.json> \
  --compiler scripts/compile_agent_package.py \
  --compiled-dir <compiled-agent-dir> \
  --state-file <agent-release-state.json>
```

Any post-receipt mutation of bound inputs, compiler, or compiled output invalidates the receipt.

## Harness evals

`evals/release_harness_cases.json` is executed by `scripts/run_release_harness_evals.py`. These are tests of the local release harness itself. They are not conversation-behavior tests.

Required cases include:

- clean static release;
- stale input detection;
- stale compiled-output detection;
- prospect/audit identity mismatch blocking;
- explicit distinction between eval specification and eval execution;
- invalid state-transition blocking;
- generated run-id uniqueness;
- explicit run-id preservation;
- unsafe/path-like run-id rejection.

## Future boundary

Future phases may add externally executed evidence for states such as `BEHAVIOR_TESTED`, `TOOLS_VERIFIED`, or `PLATFORM_VERIFIED`. Those states are intentionally absent from the A1-A4 state schema. Do not add them without an executable evidence source and an explicit adapter contract.
