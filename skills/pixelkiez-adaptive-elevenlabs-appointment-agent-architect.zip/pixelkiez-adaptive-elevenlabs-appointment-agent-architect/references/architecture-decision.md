# Architecture Decision

## Selected

Use a modular schema-first compiler with explicit source/evidence, compliance, runtime, and release boundaries. Add an offline A1-A4 release harness around the existing pure compiler rather than putting evidence logic or external side effects into the compiler itself.

## Preserved core

`compile_agent_package.py` remains the deterministic compiler for structured Pixelkiez agent inputs. It performs no network calls and no third-party mutations.

## A1-A4 extension

Add four local reliability capabilities:

1. build receipt binding config, industry capsule, audit packet, compiler bytes, local execution results, eval-spec digests, and compiled output by SHA-256;
2. release orchestrator that executes the existing validation/compile chain and emits receipt plus state;
3. non-skippable local state machine ending at `STATIC_VALIDATED` or `BLOCKED`;
4. executable harness regression cases for clean release, stale input/output, identity mismatch, eval-spec-vs-execution separation, invalid state jumps, and run identity.

## Rejected alternatives

### Monolithic prospect-specific prompt

Reject a single prospect-specific ElevenLabs system prompt or full per-call prompt override because it couples mutable prospect/audit data to stable policy and weakens provenance and safe reuse.

### Receipt logic inside the compiler

Reject embedding receipt/state logic into `compile_agent_package.py`. That would mix content compilation with release evidence and make future platform adapters harder to isolate.

### Treating scenario files as executed tests

Reject deriving `BEHAVIOR_TESTED` from the presence or schema validity of conversation scenarios. Scenario definitions are specifications until an execution engine actually runs them.

## Strongest counterargument

The wrapper adds files, hashes, state, and a second command path around an already valid compiler. For small simulations this increases procedure. The benefit is targeted: claims such as `STATIC_VALIDATED` become reproducible and stale evidence becomes detectable. The raw compiler remains available when this evidence is not needed.

## Failure-mode chain

Without the harness: valid input once -> later input/output mutation -> old validation language reused -> false-green release claim -> platform or live-call confidence without matching evidence.

With the harness: exact input/compiler/output digests -> local state transition -> receipt verification -> mutation detection -> stale evidence blocks the claim.

## Pre-build gate

`PASS_WITH_ASSUMPTIONS`: A1-A4 is local and does not require ElevenLabs API integration. Behavioral, platform, tool, telephony, and legal release evidence remain explicitly outside scope.
