# Architecture Decision

## Selected

Modular schema-first compiler with explicit source/evidence, compliance, runtime, and release boundaries.

## Rejected main alternative

A prospect-specific monolithic ElevenLabs system prompt or full per-call prompt override.

## Reason

The modular design keeps stable guardrails distinct from untrusted prospect/audit data, allows deterministic validation, minimizes prompt injection/drift, and maps cleanly to verified ElevenLabs capabilities such as Dynamic Variables and separate platform settings.

## Strongest counterargument

A monolithic prompt is easier to deploy and may require fewer moving parts. This is rejected because ease of deployment would come at the cost of claim provenance, compliance gating, testability, and safe reuse across prospects.

## Failure-mode chain

Raw website text -> instruction injection or unsupported claim -> spoken false statement -> pressure-based meeting invitation -> fake/unauthorized booking. The architecture breaks this chain through structured audit validation, claim classes, compliance gates, tool contracts, scenario evals, and positive-tool-result checks.

## Pre-build gate

`PASS_WITH_ASSUMPTIONS`: missing project foundation files and external production approvals do not block the architecture package because they are explicitly modeled as MISSING/external blockers.
