# Security and Tools

## Least privilege

The base skill is offline/read-only with respect to third parties. Compiler/validators read local files and write local artifacts only. They make no network calls.

## External tool boundary

Calendar/CRM/telephony/ElevenLabs mutations are not implemented. Any later adapter must document authentication, consent/permission, data classification, rate limits if known, logging/audit, idempotency, write scope, rollback/failure behavior, and read-only evaluation mode.

## Meeting tool contract

`get_available_slots(date_range, duration, timezone, consultant_id) -> slot_ids, display_times`

`book_meeting(confirmed_slot_id, prospect_name, contact_channel, company, meeting_reason, idempotency_key) -> booking_id, confirmed_time, status`

Hard rules:

1. Fetch availability before promising a slot.
2. Offer only returned slots.
3. Require explicit user confirmation before booking.
4. Use idempotency.
5. Inspect tool result.
6. Read back date, time, and timezone.
7. Never report success on error/timeout/ambiguous status.
8. If capability is absent, fall back to human follow-up.

## Side effects

Every future side-effect action requires an explicit permission boundary; `allowed-tools` or similar metadata is never treated as a complete security sandbox.
