# Installability and Distribution

The package controls `SKILL.md`, `agents/openai.yaml`, folder structure, deterministic validators, the ZIP structure, and the artifact name `skill.zip`.

It does not control whether a ChatGPT client/workspace renders an install button, permits installation, or exposes a particular feature.

A successful installability gate means package-structure readiness only.
