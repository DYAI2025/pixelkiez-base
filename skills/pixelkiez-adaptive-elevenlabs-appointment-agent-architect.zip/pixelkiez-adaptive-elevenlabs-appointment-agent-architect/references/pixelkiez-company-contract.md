# Pixelkiez Company Contract

## CURRENT_VERIFIED_PUBLIC_FACT

Verified 2026-08-26 from `https://pixelkiez.de/en/`:

- Pixelkiez publicly positions itself around professional websites for mid-sized companies.
- The public site emphasizes fixed-price scope before work, client ownership, optional support, and one direct contact.
- It describes three website jobs: be found, be understood, and be reachable.
- It states that projects start with diagnosis before build.
- Public service areas include web design/redesign, recruiting/applications, SEO, and GEO/agent readiness.
- The public process begins with a first call/project check to clarify goal, audience, scope, and key features.
- Paid advertising management, social community management, standalone branding, native app development, and bespoke automation pipelines are publicly listed as outside the portfolio.

## APPROVED_INTERNAL_FACT

Project-design rules approved by the supplied build contract:

- The AI agent performs transparent first contact, evidence-bound audit hook, context/relevance clarification, limited discovery, readiness detection, and qualified human handoff.
- Human consultation owns strategic interpretation, prioritization, connection to business goals, concept development, individual advice, and commercial offer.

## VNEXT_DESIGN

- A structured website score/audit may be used only when its methodology status is `APPROVED_INTERNAL`.
- Calendar/CRM calls may be added only through explicit tool contracts and permission boundaries.

## PROHIBITED_CLAIM

- Do not call an unapproved scorecard a current public Pixelkiez standard.
- Do not invent customer counts, conversion lifts, ranking success, ROI, case studies, consultant identity, proprietary methodology, or market leadership.
- Do not claim Pixelkiez offers services that its current public site explicitly excludes.

## MISSING

- Final approved score/audit standard.
- Exact human consultant(s), meeting duration, meeting title, and final offer definition.
- Approved outbound calling campaign rules and dialer configuration.

## SOURCE_NEEDED

Any internal sales claim not present in this contract or a versioned approved internal source.
