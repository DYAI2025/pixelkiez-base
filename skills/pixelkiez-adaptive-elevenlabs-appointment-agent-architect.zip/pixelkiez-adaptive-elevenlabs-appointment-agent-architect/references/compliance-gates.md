# Compliance Gates

This is a technical fail-closed policy, not legal advice and not an automatic legal classifier.

## Required external fields

- `compliance_status`: `APPROVED | BLOCKED | LEGAL_REVIEW_REQUIRED`
- `do_not_contact`: boolean
- `lead_source`: string
- `jurisdiction`: string
- `contact_type`: `B2B`
- `ai_disclosure_required`: boolean
- `recording_status`: `OFF | APPROVED | LEGAL_REVIEW_REQUIRED`

## Precall rule

Live-call eligibility requires at minimum externally supplied `compliance_status=APPROVED`, `do_not_contact=false`, and recording configuration consistent with its external approval. The conversational model cannot upgrade any status.

## Current primary-source context (verified 2026-08-26)

- German UWG §7 distinguishes telephone advertising to consumers from other market participants and uses different consent language; this skill does not decide whether a concrete B2B lead meets the legal standard.
- EU AI Act Article 50 requires transparency for AI systems intended to interact directly with natural persons unless the AI nature is obvious under the stated test; this project adopts explicit AI disclosure regardless.
- German StGB §201 is relevant to unauthorized recording of non-public spoken words; this skill therefore leaves recording approval external and fail-closed.

## Block conditions

`BLOCKED`, `LEGAL_REVIEW_REQUIRED`, `do_not_contact=true`, or unresolved recording review prevents `PRODUCTION_READY_FOR_LIVE_CALLING`. Architecture compilation for simulation remains allowed.
