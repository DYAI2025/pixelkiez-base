#!/usr/bin/env python3
import sys,json,hashlib
from pathlib import Path
from _common import fail,skill_root
from pipeline_ledger import digest
REQ_PRE=['INTAKE_COMPLETED','RESEARCH_COMPLETED','CAPABILITY_DECISION_COMPLETED','ARCHITECTURE_GATE_PASSED','DRAFT_FROZEN'];REQ_POST=['RELEASE_GATE_PASSED','EVALUATOR_PASSED','VALIDATION_PASSED','PACKAGE_AUTHORIZED']
def main(argv):
    if len(argv)!=2:return fail('usage: validate_pipeline_ledger.py <skill-dir>')
    root=skill_root(argv[1]);p=root/'reports/pipeline-events.jsonl'
    if not p.exists():return fail('pipeline ledger missing')
    evs=[json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()];prev='GENESIS'
    for i,e in enumerate(evs,1):
        if e['seq']!=i or e['prev_hash']!=prev:return fail('ledger sequence/hash chain mismatch')
        chk=dict(e);eh=chk.pop('event_hash');calc=hashlib.sha256(json.dumps(chk,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
        if eh!=calc:return fail('event hash mismatch')
        prev=eh
    types=[e['event_type'] for e in evs]
    pos=-1
    for t in REQ_PRE+REQ_POST:
        try:i=types.index(t,pos+1)
        except ValueError:return fail(f'missing/out-of-order event {t}')
        pos=i
    frozen=[e for e in evs if e['event_type']=='DRAFT_FROZEN'][-1];fd=frozen.get('artifact_digest')
    if not fd or fd!=digest(root):return fail('STALE_ARTIFACT_DIGEST')
    for t in REQ_POST:
        e=[x for x in evs if x['event_type']==t][-1]
        if e.get('artifact_digest')!=fd:return fail(f'digest mismatch at {t}')
    print(f'PASS: pipeline ledger digest={fd}');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
