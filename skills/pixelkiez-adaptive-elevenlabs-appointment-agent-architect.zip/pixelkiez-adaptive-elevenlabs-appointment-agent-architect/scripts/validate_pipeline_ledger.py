#!/usr/bin/env python3
import sys
import json
import hashlib
from _common import fail, skill_root
from pipeline_ledger import digest

REQ_PRE = ['INTAKE_COMPLETED', 'RESEARCH_COMPLETED', 'CAPABILITY_DECISION_COMPLETED', 'ARCHITECTURE_GATE_PASSED', 'DRAFT_FROZEN']
REQ_POST = ['RELEASE_GATE_PASSED', 'EVALUATOR_PASSED', 'VALIDATION_PASSED', 'PACKAGE_AUTHORIZED']


def find_in_order(types, required, start, end):
    pos = start - 1
    for item in required:
        found = None
        for i in range(pos + 1, end):
            if types[i] == item:
                found = i
                break
        if found is None:
            return None, item
        pos = found
    return pos, None


def main(argv):
    if len(argv) != 2:
        return fail('usage: validate_pipeline_ledger.py <skill-dir>')
    root = skill_root(argv[1])
    p = root / 'reports' / 'pipeline-events.jsonl'
    if not p.exists():
        return fail('pipeline ledger missing')
    evs = [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
    if not evs:
        return fail('pipeline ledger empty')
    run_ids = {e.get('run_id') for e in evs}
    if None in run_ids or '' in run_ids or len(run_ids) != 1:
        return fail('ledger must contain exactly one non-empty run_id')

    prev = 'GENESIS'
    for i, e in enumerate(evs, 1):
        if e['seq'] != i or e['prev_hash'] != prev:
            return fail('ledger sequence/hash chain mismatch')
        chk = dict(e)
        eh = chk.pop('event_hash')
        calc = hashlib.sha256(json.dumps(chk, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
        if eh != calc:
            return fail('event hash mismatch')
        prev = eh

    types = [e['event_type'] for e in evs]
    freeze_indexes = [i for i, t in enumerate(types) if t == 'DRAFT_FROZEN']
    if not freeze_indexes:
        return fail('missing DRAFT_FROZEN')
    latest_freeze_idx = freeze_indexes[-1]

    _, missing_pre = find_in_order(types, REQ_PRE, 0, latest_freeze_idx + 1)
    if missing_pre:
        return fail(f'missing/out-of-order pre-freeze event {missing_pre}')
    _, missing_post = find_in_order(types, REQ_POST, latest_freeze_idx + 1, len(types))
    if missing_post:
        return fail(f'missing/out-of-order post-freeze event {missing_post}')

    frozen = evs[latest_freeze_idx]
    fd = frozen.get('artifact_digest')
    if not fd or fd != digest(root):
        return fail('STALE_ARTIFACT_DIGEST')
    for t in REQ_POST:
        candidates = [x for x in evs[latest_freeze_idx + 1:] if x['event_type'] == t]
        if not candidates:
            return fail(f'missing post-freeze event {t}')
        if candidates[-1].get('artifact_digest') != fd:
            return fail(f'digest mismatch at {t}')
    print(f"PASS: pipeline ledger run_id={next(iter(run_ids))} digest={fd}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
