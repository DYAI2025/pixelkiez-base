#!/usr/bin/env python3
import sys, json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _common import fail
def main(argv):
    if len(argv)!=2:return fail('usage: validate_build_config.py <agent-build-config.json>')
    p=Path(argv[1]);root=Path(__file__).resolve().parents[1]
    try:
        s=json.loads((root/'schemas/agent-build-config.schema.json').read_text(encoding='utf-8'));d=json.loads(p.read_text(encoding='utf-8'));Draft202012Validator(s,format_checker=FormatChecker()).validate(d)
    except Exception as e:return fail(str(e))
    if not d['compliance']['ai_disclosure_required']:return fail('project hard rule requires ai_disclosure_required=true')
    print('PASS: build config');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
