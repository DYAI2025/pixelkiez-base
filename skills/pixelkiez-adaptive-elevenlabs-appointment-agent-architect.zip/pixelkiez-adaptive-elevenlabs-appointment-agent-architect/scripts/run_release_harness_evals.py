#!/usr/bin/env python3
from __future__ import annotations
import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REQUIRED_KINDS = {
    'clean_static_release',
    'stale_input_digest',
    'stale_output_digest',
    'identity_mismatch_blocks',
    'eval_spec_not_execution',
    'invalid_state_transition',
    'dynamic_run_identity',
    'explicit_run_identity',
    'unsafe_run_identity',
}


def run(argv: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(argv, text=True, capture_output=True)


def parse_last_json(stdout: str) -> dict:
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if line.startswith('{'):
            return json.loads(line)
    raise ValueError('no JSON result found')


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location('_release_harness_eval_module', path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def build_release(root: Path, temp: Path, suffix: str, run_id: str | None = None) -> dict:
    config = temp / f'{suffix}-config.json'
    industry = temp / f'{suffix}-industry.json'
    audit = temp / f'{suffix}-audit.json'
    shutil.copy2(root / 'examples' / 'agent-build-config.example.json', config)
    shutil.copy2(root / 'examples' / 'industry-context.example.json', industry)
    shutil.copy2(root / 'examples' / 'website-audit-packet.example.json', audit)
    out = temp / f'{suffix}-compiled'
    evidence = temp / f'{suffix}-evidence'
    argv = [
        sys.executable, str(root / 'scripts' / 'run_agent_release.py'),
        '--config', str(config), '--industry', str(industry), '--audit', str(audit),
        '--out', str(out), '--evidence-dir', str(evidence),
    ]
    if run_id:
        argv.extend(['--run-id', run_id])
    proc = run(argv)
    assert_true(proc.returncode == 0, f'release failed: {proc.stderr} {proc.stdout}')
    result = parse_last_json(proc.stdout)
    return {'result': result, 'config': config, 'industry': industry, 'audit': audit, 'out': out}


def validate_receipt(root: Path, fixture: dict) -> str | None:
    sys.path.insert(0, str(root / 'scripts'))
    module = load_module(root / 'scripts' / 'validate_agent_build_receipt.py')
    result = fixture['result']
    return module.validate_receipt(
        Path(result['receipt']),
        fixture['config'], fixture['industry'], fixture['audit'],
        root / 'scripts' / 'compile_agent_package.py', fixture['out'], Path(result['state_file'])
    )


def clone_fixture(base: dict, temp: Path, suffix: str) -> dict:
    target = temp / suffix
    target.mkdir()
    config = target / 'config.json'
    industry = target / 'industry.json'
    audit = target / 'audit.json'
    out = target / 'compiled'
    evidence = target / 'evidence'
    shutil.copy2(base['config'], config)
    shutil.copy2(base['industry'], industry)
    shutil.copy2(base['audit'], audit)
    shutil.copytree(base['out'], out)
    evidence.mkdir()
    receipt = evidence / 'agent-build-receipt.json'
    state = evidence / 'agent-release-state.json'
    shutil.copy2(base['result']['receipt'], receipt)
    shutil.copy2(base['result']['state_file'], state)
    result = dict(base['result'])
    result['receipt'] = str(receipt)
    result['state_file'] = str(state)
    return {'result': result, 'config': config, 'industry': industry, 'audit': audit, 'out': out}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('skill_dir')
    a = ap.parse_args()
    root = Path(a.skill_dir).resolve()
    cases = json.loads((root / 'evals' / 'release_harness_cases.json').read_text(encoding='utf-8'))
    kinds = {x.get('kind') for x in cases if isinstance(x, dict)}
    missing = REQUIRED_KINDS - kinds
    if missing:
        print('FAIL: missing harness eval kinds: ' + ', '.join(sorted(missing)), file=sys.stderr)
        return 1

    results = []
    with tempfile.TemporaryDirectory(prefix='pixelkiez-release-harness-') as td:
        temp = Path(td)
        print('RUN RH-001 clean_static_release', flush=True)
        try:
            base = build_release(root, temp, 'base')
            error = validate_receipt(root, base)
            assert_true(error is None, str(error))
            receipt = json.loads(Path(base['result']['receipt']).read_text(encoding='utf-8'))
            assert_true(receipt['state'] == 'STATIC_VALIDATED', 'receipt state mismatch')
            results.append({'id': 'RH-001', 'status': 'PASS'})
        except Exception as exc:
            print(json.dumps({'suite': 'release-harness', 'cases': [{'id': 'RH-001', 'status': 'FAIL', 'reason': str(exc)}], 'passed': 0, 'failed': 1}, ensure_ascii=False))
            return 1

        print('RUN RH-002 stale_input_digest', flush=True)
        try:
            fx = clone_fixture(base, temp, 'stale-input')
            data = json.loads(fx['config'].read_text(encoding='utf-8'))
            data['campaign']['campaign_id'] = 'MUTATED-AFTER-RECEIPT'
            fx['config'].write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
            error = validate_receipt(root, fx)
            assert_true(error is not None and 'STALE_INPUT_DIGEST' in error, 'stale input was not blocked')
            results.append({'id': 'RH-002', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-002', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-003 stale_output_digest', flush=True)
        try:
            fx = clone_fixture(base, temp, 'stale-output')
            with (fx['out'] / 'FIRST_MESSAGE.md').open('a', encoding='utf-8') as f:
                f.write('\nmutated after receipt\n')
            error = validate_receipt(root, fx)
            assert_true(error is not None and 'STALE_COMPILED_OUTPUT_DIGEST' in error, 'stale output was not blocked')
            results.append({'id': 'RH-003', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-003', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-004 identity_mismatch_blocks', flush=True)
        try:
            config = temp / 'mismatch-config.json'
            industry = temp / 'mismatch-industry.json'
            audit = temp / 'mismatch-audit.json'
            shutil.copy2(root / 'examples' / 'agent-build-config.example.json', config)
            shutil.copy2(root / 'examples' / 'industry-context.example.json', industry)
            data = json.loads((root / 'examples' / 'website-audit-packet.example.json').read_text(encoding='utf-8'))
            data['company'] = 'Different Company GmbH'
            audit.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
            evidence = temp / 'mismatch-evidence'
            proc = run([
                sys.executable, str(root / 'scripts' / 'run_agent_release.py'), '--config', str(config),
                '--industry', str(industry), '--audit', str(audit), '--out', str(temp / 'mismatch-compiled'),
                '--evidence-dir', str(evidence),
            ])
            assert_true(proc.returncode != 0, 'identity mismatch did not block')
            state = json.loads((evidence / 'agent-release-state.json').read_text(encoding='utf-8'))
            assert_true(state['current_state'] == 'BLOCKED', 'blocked run did not record BLOCKED state')
            results.append({'id': 'RH-004', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-004', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-005 eval_spec_not_execution', flush=True)
        try:
            receipt = json.loads(Path(base['result']['receipt']).read_text(encoding='utf-8'))
            assert_true(receipt['release_claims']['behavioral_validation'] == 'NOT_EXECUTED', 'behavioral validation was falsely promoted')
            assert_true(receipt['eval_evidence']['conversation_scenarios']['execution_status'] == 'NOT_EXECUTED_AS_AGENT_BEHAVIOR', 'eval spec was treated as execution')
            results.append({'id': 'RH-005', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-005', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-006 invalid_state_transition', flush=True)
        try:
            sys.path.insert(0, str(root / 'scripts'))
            module = load_module(root / 'scripts' / '_release_harness.py')
            state = module.new_state('run-test', 'build-test')
            try:
                module.transition(state, 'COMPILED', 'invalid jump')
            except ValueError:
                results.append({'id': 'RH-006', 'status': 'PASS'})
            else:
                raise AssertionError('invalid state transition was accepted')
        except Exception as exc:
            results.append({'id': 'RH-006', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-007 dynamic_run_identity', flush=True)
        try:
            sys.path.insert(0, str(root / 'scripts'))
            module = load_module(root / 'scripts' / '_release_harness.py')
            one = module.resolve_run_id(None)
            two = module.resolve_run_id(None)
            assert_true(one != two and one.startswith('pkz-agent-') and two.startswith('pkz-agent-'), 'automatic run ids are not unique or namespaced')
            results.append({'id': 'RH-007', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-007', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-008 explicit_run_identity', flush=True)
        try:
            sys.path.insert(0, str(root / 'scripts'))
            module = load_module(root / 'scripts' / '_release_harness.py')
            fixed = module.resolve_run_id('fixed-harness-run-id')
            assert_true(fixed == 'fixed-harness-run-id', 'explicit run id was not preserved')
            results.append({'id': 'RH-008', 'status': 'PASS'})
        except Exception as exc:
            results.append({'id': 'RH-008', 'status': 'FAIL', 'reason': str(exc)})

        print('RUN RH-009 unsafe_run_identity', flush=True)
        try:
            sys.path.insert(0, str(root / 'scripts'))
            module = load_module(root / 'scripts' / '_release_harness.py')
            try:
                module.resolve_run_id('../unsafe/run')
            except ValueError:
                results.append({'id': 'RH-009', 'status': 'PASS'})
            else:
                raise AssertionError('unsafe run id was accepted')
        except Exception as exc:
            results.append({'id': 'RH-009', 'status': 'FAIL', 'reason': str(exc)})

    failed = [x for x in results if x['status'] != 'PASS']
    report = {'suite': 'release-harness', 'cases': results, 'passed': len(results) - len(failed), 'failed': len(failed)}
    print(json.dumps(report, ensure_ascii=False))
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
