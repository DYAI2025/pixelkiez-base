#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import subprocess
import sys
from pathlib import Path
from _release_harness import new_state, resolve_run_id, sha256_bytes, transition, write_json
from create_agent_build_receipt import create_receipt


def run_step(step_id: str, target: str, argv: list[str]) -> dict:
    proc = subprocess.run(argv, text=True, capture_output=True)
    return {
        'id': step_id,
        'target': target,
        'exit_code': proc.returncode,
        'status': 'PASS' if proc.returncode == 0 else 'FAIL',
        'stdout_sha256': sha256_bytes(proc.stdout.encode('utf-8')),
        'stderr_sha256': sha256_bytes(proc.stderr.encode('utf-8')),
        '_stdout': proc.stdout,
        '_stderr': proc.stderr,
    }


def public_result(result: dict) -> dict:
    return {k: v for k, v in result.items() if not k.startswith('_')}


def fail_with_state(state: dict, state_path: Path, reason: str, result: dict | None = None) -> int:
    if state['current_state'] != 'BLOCKED':
        try:
            transition(state, 'BLOCKED', reason)
        except ValueError:
            pass
    write_json(state_path, state)
    if result:
        if result.get('_stdout'):
            print(result['_stdout'].strip())
        if result.get('_stderr'):
            print(result['_stderr'].strip(), file=sys.stderr)
    print(json.dumps({'status': 'BLOCKED', 'reason': reason, 'state_file': str(state_path)}, ensure_ascii=False))
    return 1


def main() -> int:
    ap = argparse.ArgumentParser(description='Run an offline evidence-bound Pixelkiez agent static release.')
    ap.add_argument('--config', required=True)
    ap.add_argument('--industry', required=True)
    ap.add_argument('--audit', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--evidence-dir')
    ap.add_argument('--run-id')
    a = ap.parse_args()

    root = Path(__file__).resolve().parents[1]
    config = Path(a.config).resolve()
    industry = Path(a.industry).resolve()
    audit = Path(a.audit).resolve()
    out = Path(a.out).resolve()
    try:
        run_id = resolve_run_id(a.run_id)
    except ValueError as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        return 1
    evidence_dir = Path(a.evidence_dir).resolve() if a.evidence_dir else Path(str(out) + '.evidence') / run_id
    try:
        evidence_dir.relative_to(out)
    except ValueError:
        pass
    else:
        print('FAIL: evidence-dir must not be inside compiled output directory', file=sys.stderr)
        return 1
    evidence_dir.mkdir(parents=True, exist_ok=True)
    state_path = evidence_dir / 'agent-release-state.json'

    try:
        cfg = json.loads(config.read_text(encoding='utf-8'))
        build_id = cfg['build_id']
    except Exception as exc:
        print(f'FAIL: cannot read build_id: {exc}', file=sys.stderr)
        return 1

    state = new_state(run_id, build_id)
    write_json(state_path, state)
    results: list[dict] = []

    validators = [
        ('validate_build_config', 'agent-build-config', [sys.executable, str(root / 'scripts' / 'validate_build_config.py'), str(config)]),
        ('validate_industry_context', 'industry-context', [sys.executable, str(root / 'scripts' / 'validate_industry_context.py'), str(industry)]),
        ('validate_audit_packet', 'website-audit-packet', [sys.executable, str(root / 'scripts' / 'validate_audit_packet.py'), str(audit)]),
    ]
    for step_id, target, argv in validators:
        result = run_step(step_id, target, argv)
        results.append(result)
        if result['status'] != 'PASS':
            return fail_with_state(state, state_path, f'{step_id} failed', result)
    transition(state, 'INPUTS_VALIDATED', 'all three domain input validators passed')
    write_json(state_path, state)

    compiler = root / 'scripts' / 'compile_agent_package.py'
    compile_result = run_step(
        'compile_agent_package',
        'compiled-agent-dir',
        [sys.executable, str(compiler), '--config', str(config), '--industry', str(industry), '--audit', str(audit), '--out', str(out)],
    )
    results.append(compile_result)
    if compile_result['status'] != 'PASS':
        return fail_with_state(state, state_path, 'compile_agent_package failed', compile_result)
    transition(state, 'COMPILED', 'compiler completed with exit code 0')
    write_json(state_path, state)

    package_result = run_step(
        'validate_agent_package',
        'compiled-agent-dir',
        [sys.executable, str(root / 'scripts' / 'validate_agent_package.py'), str(out)],
    )
    results.append(package_result)
    if package_result['status'] != 'PASS':
        return fail_with_state(state, state_path, 'validate_agent_package failed', package_result)
    transition(state, 'STATIC_VALIDATED', 'compiled agent package validator passed')
    write_json(state_path, state)

    public_results = [public_result(x) for x in results]
    receipt = create_receipt(root, run_id, config, industry, audit, compiler, out, public_results)
    receipt_path = evidence_dir / 'agent-build-receipt.json'
    write_json(receipt_path, receipt)

    receipt_result = run_step(
        'validate_agent_build_receipt',
        'agent-build-receipt',
        [
            sys.executable,
            str(root / 'scripts' / 'validate_agent_build_receipt.py'),
            str(receipt_path),
            '--config', str(config),
            '--industry', str(industry),
            '--audit', str(audit),
            '--compiler', str(compiler),
            '--compiled-dir', str(out),
            '--state-file', str(state_path),
        ],
    )
    if receipt_result['status'] != 'PASS':
        return fail_with_state(state, state_path, 'validate_agent_build_receipt failed', receipt_result)

    print(json.dumps({
        'status': 'STATIC_VALIDATED',
        'run_id': run_id,
        'build_id': build_id,
        'compiled_agent_dir': str(out),
        'evidence_dir': str(evidence_dir),
        'receipt': str(receipt_path),
        'state_file': str(state_path),
        'behavioral_validation': 'NOT_EXECUTED',
        'platform_validation': 'NOT_EXECUTED',
        'live_calling': 'NOT_AUTHORIZED',
    }, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
