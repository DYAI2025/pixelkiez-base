#!/usr/bin/env python3
from pathlib import Path
import sys, json
from jsonschema import Draft202012Validator
from _common import fail, skill_root

def main(argv):
    if len(argv)!=2: return fail("usage: validate_schemas.py <skill-dir>")
    root=skill_root(argv[1]); files=sorted((root/'schemas').glob('*.json'))
    if len(files)<5: return fail("expected at least 5 schemas")
    for p in files:
        try:
            data=json.loads(p.read_text(encoding='utf-8')); Draft202012Validator.check_schema(data)
        except Exception as e: return fail(f"invalid schema {p.name}: {e}")
    print(f"PASS: schemas ({len(files)})"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv))
