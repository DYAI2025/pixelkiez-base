#!/usr/bin/env python3
import sys,json
from jsonschema import Draft202012Validator
from _common import fail,skill_root
def main(argv):
    if len(argv)!=2:return fail('usage: validate_capability_record.py <skill-dir>')
    root=skill_root(argv[1]);s=json.loads((root/'schemas/capability-record.schema.json').read_text(encoding='utf-8'));records=json.loads((root/'reports/capability-records.json').read_text(encoding='utf-8'))
    if len(records)<8:return fail('insufficient capability records')
    for r in records:
        try:Draft202012Validator(s).validate(r)
        except Exception as e:return fail(f"{r.get('capability_id')}: {e}")
        if r['adoption_state']=='ADOPTED' and (r['verification_status']!='PRIMARY_VERIFIED' or r['confidence']<4):return fail('adopted capability lacks primary verification')
    print('PASS: capability records');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
