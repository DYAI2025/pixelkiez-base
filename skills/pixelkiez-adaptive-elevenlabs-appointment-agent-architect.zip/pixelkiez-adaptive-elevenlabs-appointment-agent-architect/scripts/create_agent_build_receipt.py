#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _release_harness import file_count, sha256_file, tree_digest, utc_now, write_json


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def count_jsonl(path: Path) -> int:
    return sum(1 for line in path.read_text(encoding='utf-8').splitlines() if line.strip())


def create_receipt(root: Path, run_id: str, config: Path, industry: Path, audit: Path,
                   compiler: Path, compiled_dir: Path, execution_results: list[dict]) -> dict:
    cfg = load_json(config)
    conversation = root / 'evals' / 'conversation_scenarios.jsonl'
    harness_cases = root / 'evals' / 'release_harness_cases.json'
    harness_data = load_json(harness_cases)
    receipt = {
        'schema_version': '1.0',
        'run_id': run_id,
        'build_id': cfg['build_id'],
        'created_at': utc_now(),
        'state': 'STATIC_VALIDATED',
        'inputs': {
            'config': {'name': config.name, 'sha256': sha256_file(config)},
            'industry': {'name': industry.name, 'sha256': sha256_file(industry)},
            'audit': {'name': audit.name, 'sha256': sha256_file(audit)},
        },
        'compiler': {'name': compiler.name, 'sha256': sha256_file(compiler)},
        'compiled_output': {
            'directory_name': compiled_dir.name,
            'tree_sha256': tree_digest(compiled_dir),
            'file_count': file_count(compiled_dir),
        },
        'execution_results': execution_results,
        'eval_evidence': {
            'conversation_scenarios': {
                'name': conversation.name,
                'sha256': sha256_file(conversation),
                'case_count': count_jsonl(conversation),
                'execution_status': 'NOT_EXECUTED_AS_AGENT_BEHAVIOR',
            },
            'release_harness_cases': {
                'name': harness_cases.name,
                'sha256': sha256_file(harness_cases),
                'case_count': len(harness_data),
                'execution_status': 'NOT_EXECUTED_AS_AGENT_BEHAVIOR',
            },
        },
        'release_claims': {
            'static_validation': 'PASS',
            'behavioral_validation': 'NOT_EXECUTED',
            'platform_validation': 'NOT_EXECUTED',
            'live_calling': 'NOT_AUTHORIZED',
        },
    }
    schema = load_json(root / 'schemas' / 'agent-build-receipt.schema.json')
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(receipt)
    return receipt


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-id', required=True)
    ap.add_argument('--config', required=True)
    ap.add_argument('--industry', required=True)
    ap.add_argument('--audit', required=True)
    ap.add_argument('--compiler', required=True)
    ap.add_argument('--compiled-dir', required=True)
    ap.add_argument('--execution-results', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    receipt = create_receipt(
        root,
        a.run_id,
        Path(a.config).resolve(),
        Path(a.industry).resolve(),
        Path(a.audit).resolve(),
        Path(a.compiler).resolve(),
        Path(a.compiled_dir).resolve(),
        load_json(Path(a.execution_results).resolve()),
    )
    write_json(Path(a.out).resolve(), receipt)
    print(f'PASS: build receipt {a.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
