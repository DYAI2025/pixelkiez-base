#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _release_harness import file_count, sha256_file, tree_digest


def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def validate_receipt(receipt_path: Path, config: Path, industry: Path, audit: Path,
                     compiler: Path, compiled_dir: Path, state_file: Path) -> str | None:
    root = Path(__file__).resolve().parents[1]
    try:
        receipt = load(receipt_path)
        schema = load(root / 'schemas' / 'agent-build-receipt.schema.json')
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(receipt)
        state = load(state_file)
        state_schema = load(root / 'schemas' / 'agent-release-state.schema.json')
        Draft202012Validator(state_schema, format_checker=FormatChecker()).validate(state)
    except Exception as exc:
        return f'schema/state validation: {exc}'

    paths = {'config': config, 'industry': industry, 'audit': audit}
    for key, path in paths.items():
        if sha256_file(path) != receipt['inputs'][key]['sha256']:
            return f'STALE_INPUT_DIGEST:{key}'
    if sha256_file(compiler) != receipt['compiler']['sha256']:
        return 'STALE_COMPILER_DIGEST'
    if tree_digest(compiled_dir) != receipt['compiled_output']['tree_sha256']:
        return 'STALE_COMPILED_OUTPUT_DIGEST'
    if file_count(compiled_dir) != receipt['compiled_output']['file_count']:
        return 'COMPILED_OUTPUT_FILE_COUNT_MISMATCH'
    cfg = load(config)
    if cfg.get('build_id') != receipt['build_id']:
        return 'BUILD_ID_MISMATCH'
    if state.get('run_id') != receipt['run_id'] or state.get('build_id') != receipt['build_id']:
        return 'STATE_RECEIPT_IDENTITY_MISMATCH'
    if state.get('current_state') != 'STATIC_VALIDATED':
        return 'STATE_NOT_STATIC_VALIDATED'
    if any(x.get('status') != 'PASS' or x.get('exit_code') != 0 for x in receipt['execution_results']):
        return 'EXECUTION_RESULT_NOT_PASS'
    claims = receipt['release_claims']
    if claims != {
        'static_validation': 'PASS',
        'behavioral_validation': 'NOT_EXECUTED',
        'platform_validation': 'NOT_EXECUTED',
        'live_calling': 'NOT_AUTHORIZED',
    }:
        return 'RELEASE_CLAIM_SCOPE_VIOLATION'
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('receipt')
    ap.add_argument('--config', required=True)
    ap.add_argument('--industry', required=True)
    ap.add_argument('--audit', required=True)
    ap.add_argument('--compiler', required=True)
    ap.add_argument('--compiled-dir', required=True)
    ap.add_argument('--state-file', required=True)
    a = ap.parse_args()
    receipt_path = Path(a.receipt).resolve()
    error = validate_receipt(
        receipt_path,
        Path(a.config).resolve(),
        Path(a.industry).resolve(),
        Path(a.audit).resolve(),
        Path(a.compiler).resolve(),
        Path(a.compiled_dir).resolve(),
        Path(a.state_file).resolve(),
    )
    if error:
        print(f'FAIL: {error}', file=sys.stderr)
        return 1
    receipt = load(receipt_path)
    print(f"PASS: agent build receipt run_id={receipt['run_id']} digest={receipt['compiled_output']['tree_sha256']}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
