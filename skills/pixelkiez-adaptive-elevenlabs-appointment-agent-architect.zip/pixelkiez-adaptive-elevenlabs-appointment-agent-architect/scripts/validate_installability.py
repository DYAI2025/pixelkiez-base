#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
def main(argv):
    if len(argv)!=2:return fail('usage: validate_installability.py <skill-dir>')
    root=skill_root(argv[1]);p=root/'reports/installability-report.json'
    if not p.exists():return fail('installability report missing')
    r=json.loads(p.read_text(encoding='utf-8'))
    if r.get('artifact_name')!='skill.zip' or r.get('chatgpt_install_ready') is not True:return fail('installability shape invalid')
    if r.get('frontend_install_suggestion_status') not in {'prepared','blocked','not_controlled_by_skill'}:return fail('invalid frontend status')
    if r.get('frontend_install_suggestion_status')=='guaranteed':return fail('frontend guarantee prohibited')
    if not (root/'SKILL.md').exists() or not (root/'agents/openai.yaml').exists():return fail('entrypoint metadata missing')
    print('PASS: installability');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
