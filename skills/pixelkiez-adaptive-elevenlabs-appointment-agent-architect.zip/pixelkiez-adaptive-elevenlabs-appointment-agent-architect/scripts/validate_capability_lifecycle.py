#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
ALLOWED={('DISCOVERED','PRIMARY_SOURCE_PENDING'),('PRIMARY_SOURCE_PENDING','VERIFIED_CANDIDATE'),('VERIFIED_CANDIDATE','ADOPTED'),('VERIFIED_CANDIDATE','EXPERIMENTAL'),('EXPERIMENTAL','ADOPTED'),('DISCOVERED','REJECTED'),('PRIMARY_SOURCE_PENDING','BLOCKED')}
def main(argv):
    if len(argv)!=2:return fail('usage: validate_capability_lifecycle.py <skill-dir>')
    root=skill_root(argv[1]);lines=[json.loads(x) for x in (root/'reports/capability-lifecycle-events.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    if not lines:return fail('lifecycle empty')
    last={}
    for i,e in enumerate(lines,1):
        if e.get('seq')!=i:return fail('non-monotonic seq')
        pair=(e['from'],e['to'])
        if pair not in ALLOWED:return fail(f'invalid transition {pair}')
        if e['from']=='DISCOVERED' and e['to']=='ADOPTED':return fail('direct discovered->adopted prohibited')
        last[e['capability_id']]=e['to']
    adopted={r['capability_id'] for r in json.loads((root/'reports/capability-records.json').read_text(encoding='utf-8')) if r['adoption_state']=='ADOPTED'}
    if any(last.get(c)!='ADOPTED' for c in adopted):return fail('adopted record lacks adopted lifecycle state')
    print('PASS: capability lifecycle');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
