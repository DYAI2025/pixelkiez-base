#!/usr/bin/env python3
import re, sys, json
from pathlib import Path
from _common import fail, skill_root
NAME_RE=re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
REQ=['SKILL.md','agents/openai.yaml','references/source-policy.md','references/source-map.md','references/pixelkiez-company-contract.md','references/website-audit-contract.md','references/elevenlabs-runtime.md','references/compliance-gates.md','schemas/industry-context.schema.json','schemas/website-audit-packet.schema.json','schemas/agent-build-config.schema.json','schemas/compiled-agent-package.schema.json','schemas/agent-build-receipt.schema.json','schemas/agent-release-state.schema.json','evals/trigger_queries.json','evals/output_evals.json','evals/conversation_scenarios.jsonl','evals/release_harness_cases.json','references/runtime-release-harness.md','scripts/run_agent_release.py','scripts/create_agent_build_receipt.py','scripts/validate_agent_build_receipt.py','scripts/run_release_harness_evals.py','reports/release-gate-report.json']
def main(argv):
    if len(argv)!=2:return fail('usage: quick_validate.py <skill-dir>')
    root=skill_root(argv[1])
    for rel in REQ:
        if not (root/rel).is_file(): return fail(f'missing required path: {rel}')
    text=(root/'SKILL.md').read_text(encoding='utf-8')
    if not text.startswith('---\n') or '\n---\n' not in text[4:]: return fail('invalid SKILL.md frontmatter')
    fm=text[4:text.find('\n---\n',4)]
    vals={}
    for line in fm.splitlines():
        if ':' in line:
            k,v=line.split(':',1);vals[k.strip()]=v.strip().strip('"\'')
    name=vals.get('name','');desc=vals.get('description','')
    if not NAME_RE.match(name) or name!=root.name:return fail('invalid/mismatched skill name')
    if not desc or len(desc)>1024 or '<' in desc or '>' in desc:return fail('invalid description')
    if len(text.splitlines())>360:return fail('SKILL.md too long; progressive disclosure violated')
    empty=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.stat().st_size==0]
    if empty:return fail('empty files: '+', '.join(empty))
    print('PASS: quick validate');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
