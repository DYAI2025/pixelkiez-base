#!/usr/bin/env python3
import sys, json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _common import fail
def main(argv):
    if len(argv)!=2:return fail('usage: validate_industry_context.py <industry-context.json>')
    p=Path(argv[1]); root=Path(__file__).resolve().parents[1]
    try:
        schema=json.loads((root/'schemas/industry-context.schema.json').read_text(encoding='utf-8')); data=json.loads(p.read_text(encoding='utf-8'))
        Draft202012Validator(schema,format_checker=FormatChecker()).validate(data)
    except Exception as e:return fail(str(e))
    if data['confidence']<3:return fail('industry context confidence below 3; research_more required')
    print('PASS: industry context');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
