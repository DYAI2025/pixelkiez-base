#!/usr/bin/env python3
import sys,xml.etree.ElementTree as ET
from pathlib import Path
from _common import fail
TAGS=['spec_compliance','research_quality','enterprise_readiness','architecture_quality','release_gate_integrity'];DEC={'PASS','PASS_WITH_MINOR_REVISIONS','REVISE','REBUILD','BLOCKED'}
def text(n):return '' if n is None or n.text is None else n.text.strip()
def main(argv):
    if len(argv)!=2:return fail('usage: validate_enterprise_skill_evaluation.py <evaluation.xml>')
    try:r=ET.parse(Path(argv[1])).getroot()
    except Exception as e:return fail(str(e))
    if r.tag!='enterprise_skill_evaluation':return fail('bad root')
    scores=r.find('scores')
    if scores is None:return fail('scores missing')
    for t in TAGS:
        if text(scores.find(t)) not in {'1','2','3','4','5'}:return fail(f'bad score {t}')
    if text(r.find('decision')) not in DEC:return fail('bad decision')
    if not text(r.find('reason')):return fail('reason missing')
    print('PASS: enterprise skill evaluation');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
