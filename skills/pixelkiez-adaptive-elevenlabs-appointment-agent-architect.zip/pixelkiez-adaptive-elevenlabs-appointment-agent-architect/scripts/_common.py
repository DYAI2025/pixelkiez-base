from __future__ import annotations
import json, sys
from pathlib import Path

def fail(msg: str) -> int:
    print(f"FAIL: {msg}", file=sys.stderr)
    return 1

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def skill_root(arg: str) -> Path:
    p=Path(arg).resolve()
    if not p.is_dir():
        raise ValueError(f"not a directory: {p}")
    return p
