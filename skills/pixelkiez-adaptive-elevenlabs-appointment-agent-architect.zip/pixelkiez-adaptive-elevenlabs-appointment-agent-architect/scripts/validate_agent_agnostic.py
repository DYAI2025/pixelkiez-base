#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
def main(argv):
    if len(argv)!=2:return fail('usage: validate_agent_agnostic.py <skill-dir>')
    root=skill_root(argv[1]);ref=(root/'references/agent-agnostic-compatibility.md').read_text(encoding='utf-8');r=json.loads((root/'reports/agent-compatibility-report.json').read_text(encoding='utf-8'))
    if not r.get('agent_agnostic_ready'):return fail('agent_agnostic_ready false')
    if 'not guaranteed' not in ref.lower():return fail('runtime limitations missing')
    if 'agents/openai.yaml' not in r.get('runtime_specific_components',[]):return fail('openai metadata boundary missing')
    print('PASS: agent-agnostic compatibility');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
