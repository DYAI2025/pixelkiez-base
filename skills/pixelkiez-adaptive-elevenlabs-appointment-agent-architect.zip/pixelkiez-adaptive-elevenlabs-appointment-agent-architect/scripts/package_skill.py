#!/usr/bin/env python3
from __future__ import annotations
import argparse
import importlib.util
import subprocess
import sys
import zipfile
from pathlib import Path

VALIDATORS = [
    'quick_validate.py',
    'validate_sources.py',
    'validate_source_map.py',
    'validate_schemas.py',
    'validate_evals.py',
    'validate_release_gate.py',
    'validate_installability.py',
    'validate_agent_agnostic.py',
    'validate_core_parity.py',
    'validate_capability_record.py',
    'validate_capability_lifecycle.py',
    'validate_no_placeholders.py',
    'validate_pipeline_ledger.py',
]


def load_module(path: Path):
    name = f'_pixelkiez_package_{path.stem}'
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SystemExit(f'FAIL: cannot load validator {path.name}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_in_process(root: Path, script: Path) -> None:
    module = load_module(script)
    if not hasattr(module, 'main'):
        raise SystemExit(f'FAIL: validator missing main(): {script.name}')
    code = module.main([script.name, str(root)])
    if code not in (None, 0):
        raise SystemExit(code)


def run_harness(root: Path, script: Path) -> None:
    result = subprocess.run([sys.executable, str(script), str(root)], text=True, capture_output=True)
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        raise SystemExit(result.returncode)


def package(root: Path, out: Path) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    zip_path = out / 'skill.zip'
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
                z.write(p, p.relative_to(root.parent))
    with zipfile.ZipFile(zip_path) as z:
        tops = {n.split('/')[0] for n in z.namelist() if n}
        if tops != {root.name}:
            raise SystemExit('FAIL: zip must contain exactly one root skill folder')
        if f'{root.name}/SKILL.md' not in z.namelist():
            raise SystemExit('FAIL: SKILL.md missing in zip')
    return zip_path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('skill_dir')
    ap.add_argument('out_dir', nargs='?', default='./dist')
    a = ap.parse_args()
    root = Path(a.skill_dir).resolve()
    scripts = root / 'scripts'
    for name in VALIDATORS:
        run_in_process(root, scripts / name)
    run_harness(root, scripts / 'run_release_harness_evals.py')
    evaluation = scripts / 'validate_enterprise_skill_evaluation.py'
    eval_module = load_module(evaluation)
    code = eval_module.main([evaluation.name, str(root / 'reports' / 'enterprise-skill-evaluation.xml')])
    if code not in (None, 0):
        raise SystemExit(code)
    zip_path = package(root, Path(a.out_dir).resolve())
    print(f'PACKAGED: {zip_path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
