#!/usr/bin/env python3
import argparse,subprocess,sys,zipfile,json
from pathlib import Path
VALIDATORS=['quick_validate.py','validate_sources.py','validate_source_map.py','validate_schemas.py','validate_evals.py','validate_release_gate.py','validate_installability.py','validate_agent_agnostic.py','validate_core_parity.py','validate_capability_record.py','validate_capability_lifecycle.py','validate_no_placeholders.py','validate_pipeline_ledger.py']
def main():
    ap=argparse.ArgumentParser();ap.add_argument('skill_dir');ap.add_argument('out_dir',nargs='?',default='./dist');a=ap.parse_args();root=Path(a.skill_dir).resolve();sd=root/'scripts'
    for n in VALIDATORS:
        r=subprocess.run([sys.executable,str(sd/n),str(root)],text=True,capture_output=True)
        if r.stdout:print(r.stdout.strip())
        if r.returncode:
            if r.stderr:print(r.stderr.strip(),file=sys.stderr)
            raise SystemExit(r.returncode)
    out=Path(a.out_dir).resolve();out.mkdir(parents=True,exist_ok=True);zp=out/'skill.zip'
    if zp.exists():zp.unlink()
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':z.write(p,p.relative_to(root.parent))
    with zipfile.ZipFile(zp) as z:
        tops={n.split('/')[0] for n in z.namelist() if n}
        if tops!={root.name}:raise SystemExit('FAIL: zip must contain exactly one root skill folder')
        if f'{root.name}/SKILL.md' not in z.namelist():raise SystemExit('FAIL: SKILL.md missing in zip')
    print(f'PACKAGED: {zp}')
if __name__=='__main__':main()
