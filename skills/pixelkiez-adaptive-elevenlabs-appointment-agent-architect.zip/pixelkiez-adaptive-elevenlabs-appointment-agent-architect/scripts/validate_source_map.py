#!/usr/bin/env python3
import sys
from _common import fail, skill_root
REQ=['type:','purpose:','reliability:','limitations:','confidence_default:','user_provided','primary','SOURCE_NEEDED','MISSING','verified_at:']
def main(argv):
    if len(argv)!=2:return fail('usage: validate_source_map.py <skill-dir>')
    root=skill_root(argv[1]); text=(root/'references/source-map.md').read_text(encoding='utf-8')+'\n'+(root/'references/source-policy.md').read_text(encoding='utf-8')
    miss=[x for x in REQ if x not in text]
    if miss:return fail('missing source terms: '+', '.join(miss))
    print('PASS: source map');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
