#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
EXCLUDE={'reports','dist','__pycache__','.git'}
def digest(root:Path)->str:
    h=hashlib.sha256()
    for p in sorted(root.rglob('*')):
        if not p.is_file() or set(p.relative_to(root).parts)&EXCLUDE or p.suffix=='.pyc':continue
        rel=str(p.relative_to(root)).replace('\\','/')
        h.update(rel.encode());h.update(b'\0');h.update(p.read_bytes());h.update(b'\0')
    return h.hexdigest()
def append(root,event_type,artifact_digest=None,data=None):
    path=root/'reports/pipeline-events.jsonl';events=[]
    if path.exists():events=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    seq=len(events)+1;prev=events[-1]['event_hash'] if events else 'GENESIS'
    ev={'seq':seq,'run_id':'pixelkiez-build-2026-08-26','event_type':event_type,'timestamp':datetime.now(timezone.utc).isoformat(),'artifact_digest':artifact_digest,'data':data or {},'prev_hash':prev}
    raw=json.dumps(ev,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();ev['event_hash']=hashlib.sha256(raw).hexdigest()
    with path.open('a',encoding='utf-8') as f:f.write(json.dumps(ev,ensure_ascii=False)+'\n')
    print(json.dumps(ev,ensure_ascii=False))
def main():
    ap=argparse.ArgumentParser();sp=ap.add_subparsers(dest='cmd',required=True)
    d=sp.add_parser('digest');d.add_argument('skill_dir')
    a=sp.add_parser('append');a.add_argument('skill_dir');a.add_argument('event_type');a.add_argument('--digest');a.add_argument('--data-json',default='{}')
    x=ap.parse_args();root=Path(x.skill_dir).resolve()
    if x.cmd=='digest':print(digest(root));return
    append(root,x.event_type,x.digest,json.loads(x.data_json))
if __name__=='__main__':main()
