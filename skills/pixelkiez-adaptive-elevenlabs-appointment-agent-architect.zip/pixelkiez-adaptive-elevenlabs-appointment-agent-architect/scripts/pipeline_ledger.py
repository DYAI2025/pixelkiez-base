#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

EXCLUDE = {'reports', 'dist', '__pycache__', '.git'}


def digest(root: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(root.rglob('*')):
        if not p.is_file() or set(p.relative_to(root).parts) & EXCLUDE or p.suffix == '.pyc':
            continue
        rel = str(p.relative_to(root)).replace('\\', '/')
        h.update(rel.encode())
        h.update(b'\0')
        h.update(p.read_bytes())
        h.update(b'\0')
    return h.hexdigest()


def append(root: Path, event_type: str, artifact_digest: str | None = None,
           data: dict | None = None, run_id: str | None = None) -> None:
    path = root / 'reports' / 'pipeline-events.jsonl'
    events = []
    if path.exists():
        events = [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
    existing_run_ids = {e.get('run_id') for e in events if e.get('run_id')}
    if run_id is None:
        if len(existing_run_ids) == 1:
            run_id = next(iter(existing_run_ids))
        elif not existing_run_ids:
            raise SystemExit('FAIL: --run-id is required for a new pipeline ledger')
        else:
            raise SystemExit('FAIL: existing ledger contains multiple run ids')
    if existing_run_ids and existing_run_ids != {run_id}:
        raise SystemExit('FAIL: run id mismatch with existing ledger')
    seq = len(events) + 1
    prev = events[-1]['event_hash'] if events else 'GENESIS'
    ev = {
        'seq': seq,
        'run_id': run_id,
        'event_type': event_type,
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'artifact_digest': artifact_digest,
        'data': data or {},
        'prev_hash': prev,
    }
    raw = json.dumps(ev, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    ev['event_hash'] = hashlib.sha256(raw).hexdigest()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(ev, ensure_ascii=False) + '\n')
    print(json.dumps(ev, ensure_ascii=False))


def main() -> None:
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest='cmd', required=True)
    d = sp.add_parser('digest')
    d.add_argument('skill_dir')
    a = sp.add_parser('append')
    a.add_argument('skill_dir')
    a.add_argument('event_type')
    a.add_argument('--digest')
    a.add_argument('--data-json', default='{}')
    a.add_argument('--run-id')
    x = ap.parse_args()
    root = Path(x.skill_dir).resolve()
    if x.cmd == 'digest':
        print(digest(root))
        return
    append(root, x.event_type, x.digest, json.loads(x.data_json), x.run_id)


if __name__ == '__main__':
    main()
