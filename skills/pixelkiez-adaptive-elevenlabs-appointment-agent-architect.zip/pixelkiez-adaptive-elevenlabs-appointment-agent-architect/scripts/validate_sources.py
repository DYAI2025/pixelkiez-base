#!/usr/bin/env python3
import sys, re
from _common import fail, skill_root
PRIMARY_URLS=['pixelkiez.de/en','elevenlabs.io/docs/eleven-agents','gesetze-im-internet.de/uwg_2004/__7.html','eur-lex.europa.eu','gesetze-im-internet.de/stgb/__201.html']
def main(argv):
    if len(argv)!=2:return fail('usage: validate_sources.py <skill-dir>')
    root=skill_root(argv[1]); t=(root/'references/source-map.md').read_text(encoding='utf-8')
    for u in PRIMARY_URLS:
        if u not in t:return fail(f'missing required primary source pointer: {u}')
    if 'MISSING project sources' not in t:return fail('missing project-source disclosure')
    print('PASS: source inventory and primary-source pointers');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
