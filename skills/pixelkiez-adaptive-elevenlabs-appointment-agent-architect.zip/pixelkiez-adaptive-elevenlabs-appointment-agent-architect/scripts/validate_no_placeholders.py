#!/usr/bin/env python3
import re,sys
from _common import fail,skill_root
PAT=re.compile(r'\{\{?[A-Z_][A-Z0-9_]*\}?\}|\b(TODO|TBD|FIXME)\b')
IGNORE={'evals','reports','examples'}
def main(argv):
    if len(argv)!=2:return fail('usage: validate_no_placeholders.py <skill-dir>')
    root=skill_root(argv[1]);hits=[]
    for p in root.rglob('*'):
        if not p.is_file() or set(p.relative_to(root).parts)&IGNORE:continue
        if p.name == 'validate_no_placeholders.py': continue
        if p.suffix not in {'.md','.py','.yaml','.json'} and p.name!='SKILL.md':continue
        for m in PAT.finditer(p.read_text(encoding='utf-8',errors='ignore')):hits.append(f'{p.relative_to(root)}:{m.group(0)}')
    if hits:return fail('unresolved placeholders: '+', '.join(hits))
    print('PASS: no unresolved placeholders');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
