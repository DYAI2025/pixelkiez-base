#!/usr/bin/env python3
import sys, json, re
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _common import fail
UNSAFE_CERTAINTY=re.compile(r'\b(guaranteed|guarantee|definitely|certainly|garantiert|sicherlich|definitiv)\b',re.I)
def main(argv):
    if len(argv)!=2:return fail('usage: validate_audit_packet.py <website-audit-packet.json>')
    p=Path(argv[1]); root=Path(__file__).resolve().parents[1]
    try:
        schema=json.loads((root/'schemas/website-audit-packet.schema.json').read_text(encoding='utf-8')); data=json.loads(p.read_text(encoding='utf-8'))
        Draft202012Validator(schema,format_checker=FormatChecker()).validate(data)
    except Exception as e:return fail(str(e))
    if data['score_method_status']=='NOT_USED' and (data['overall_score'] is not None or data['score_scale'] is not None):return fail('NOT_USED score must have null score and scale')
    if data['score_method_status']!='NOT_USED' and (data['overall_score'] is None or data['score_scale'] is None):return fail('used score requires value and scale')
    ids=set()
    for f in data['findings']:
        if f['id'] in ids:return fail('duplicate finding id');ids.add(f['id'])
        if f['evidence_class']=='UNKNOWN' and f['allowed_spoken_form'].strip():return fail(f"UNKNOWN finding {f['id']} must not have spoken form")
        if f['evidence_class'] in {'HYPOTHESIS','SUPPORTED_INFERENCE'} and UNSAFE_CERTAINTY.search(f['allowed_spoken_form']):return fail(f"unsafe certainty in {f['id']}")
    print('PASS: audit packet');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
