#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
REQ=['company contract','industry context','website audit','relevance mapping','conversation policy','elevenlabs compile','evaluation','compliance gate','release harness']
def main(argv):
    if len(argv)!=2:return fail('usage: validate_core_parity.py <skill-dir>')
    root=skill_root(argv[1]);r=json.loads((root/'reports/core-functionality-preservation.json').read_text(encoding='utf-8'))
    if r.get('status')!='PASS' or r.get('unintended_changes'):return fail('core parity report blocks')
    text=' '.join(r.get('core_functions_present',[])).lower()
    for x in REQ:
        if x not in text:return fail(f'missing core function: {x}')
    print('PASS: core functionality');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
