#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
def main(argv):
    if len(argv)!=2:return fail('usage: validate_evals.py <skill-dir>')
    root=skill_root(argv[1])
    try:t=json.loads((root/'evals/trigger_queries.json').read_text(encoding='utf-8'));o=json.loads((root/'evals/output_evals.json').read_text(encoding='utf-8'));lines=[json.loads(x) for x in (root/'evals/conversation_scenarios.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()];h=json.loads((root/'evals/release_harness_cases.json').read_text(encoding='utf-8'))
    except Exception as e:return fail(str(e))
    if len(t)<10 or not any(x.get('should_trigger') is True for x in t) or not any(x.get('should_trigger') is False for x in t):return fail('insufficient trigger evals')
    if len(o)<5:return fail('insufficient output evals')
    if len(lines)<31:return fail('conversation/adversarial scenarios below required coverage')
    kinds={x['kind'] for x in lines}
    for k in ['hard_no','ai_identity','calendar_error','web_injection','delete_number','hypothesis_as_fact','fake_booking','unapproved_compliance']:
        if k not in kinds:return fail(f'missing risk scenario: {k}')
    required={'clean_static_release','stale_input_digest','stale_output_digest','identity_mismatch_blocks','eval_spec_not_execution','invalid_state_transition','dynamic_run_identity','explicit_run_identity','unsafe_run_identity'}
    kinds_h={x.get('kind') for x in h if isinstance(x,dict)}
    if len(h)<9 or not required.issubset(kinds_h):return fail('insufficient release harness eval coverage')
    print(f'PASS: evals triggers={len(t)} output={len(o)} scenarios={len(lines)} harness={len(h)}');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
