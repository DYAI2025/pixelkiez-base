#!/usr/bin/env python3
import sys, json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
from _common import fail
REQ=['SYSTEM_PROMPT.md','FIRST_MESSAGE.md','dynamic-variables.json','audit-runtime-packet.json','industry-context.json','knowledge-base-manifest.md','pronunciation-candidates.md','system-tools.yaml','external-tools-contract.yaml','conversation-settings.md','eval-scenarios.json','release-report.md','compiled-agent-package.json']
def main(argv):
    if len(argv)!=2:return fail('usage: validate_agent_package.py <compiled-agent-dir>')
    d=Path(argv[1]).resolve()
    for f in REQ:
        if not (d/f).is_file():return fail(f'missing {f}')
    root=Path(__file__).resolve().parents[1]
    try:
        s=json.loads((root/'schemas/compiled-agent-package.schema.json').read_text(encoding='utf-8'));m=json.loads((d/'compiled-agent-package.json').read_text(encoding='utf-8'));Draft202012Validator(s,format_checker=FormatChecker()).validate(m)
    except Exception as e:return fail(str(e))
    system=(d/'SYSTEM_PROMPT.md').read_text(encoding='utf-8')
    for phrase in ['explicitly disclosed AI','Never claim to be human','Never self-authorize calling','Never promise unavailable slots']:
        if phrase not in system:return fail(f'missing invariant: {phrase}')
    print('PASS: compiled agent package');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
