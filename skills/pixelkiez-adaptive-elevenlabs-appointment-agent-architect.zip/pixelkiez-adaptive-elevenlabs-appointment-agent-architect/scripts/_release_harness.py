#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import re
import uuid
from pathlib import Path
from datetime import datetime, timezone

RUN_ID_RE = re.compile(r'^[A-Za-z0-9._-]{1,128}$')

STATE_TRANSITIONS = {
    'INIT': {'INPUTS_VALIDATED', 'BLOCKED'},
    'INPUTS_VALIDATED': {'COMPILED', 'BLOCKED'},
    'COMPILED': {'STATIC_VALIDATED', 'BLOCKED'},
    'STATIC_VALIDATED': {'BLOCKED'},
    'BLOCKED': set(),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def generate_run_id() -> str:
    return f'pkz-agent-{uuid.uuid4().hex}'


def resolve_run_id(explicit: str | None) -> str:
    value = explicit if explicit else generate_run_id()
    if not RUN_ID_RE.fullmatch(value):
        raise ValueError('run_id must match [A-Za-z0-9._-]{1,128}')
    return value


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def tree_digest(root: Path) -> str:
    root = root.resolve()
    h = hashlib.sha256()
    count = 0
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        rel = str(path.relative_to(root)).replace('\\', '/')
        h.update(rel.encode('utf-8'))
        h.update(b'\0')
        h.update(path.read_bytes())
        h.update(b'\0')
        count += 1
    return h.hexdigest()


def file_count(root: Path) -> int:
    return sum(1 for p in root.rglob('*') if p.is_file())


def new_state(run_id: str, build_id: str) -> dict:
    return {
        'run_id': run_id,
        'build_id': build_id,
        'current_state': 'INIT',
        'behavioral_execution_status': 'NOT_EXECUTED',
        'platform_execution_status': 'NOT_EXECUTED',
        'live_calling_authorization': 'NOT_AUTHORIZED',
        'history': [],
    }


def transition(state: dict, target: str, reason: str) -> None:
    current = state['current_state']
    allowed = STATE_TRANSITIONS.get(current, set())
    if target not in allowed:
        raise ValueError(f'invalid state transition: {current} -> {target}')
    state['history'].append({
        'seq': len(state['history']) + 1,
        'from': current,
        'to': target,
        'reason': reason,
        'timestamp': utc_now(),
    })
    state['current_state'] = target


def write_json(path: Path, data: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
