#!/usr/bin/env python3
import sys,json
from _common import fail,skill_root
def main(argv):
    if len(argv)!=2:return fail('usage: validate_release_gate.py <skill-dir>')
    root=skill_root(argv[1]);r=json.loads((root/'reports/release-gate-report.json').read_text(encoding='utf-8'))
    if r.get('release_gate',{}).get('status')!='PASS' or r.get('release_gate',{}).get('allowed_to_package') is not True:return fail('release gate not PASS/authorized')
    if r.get('craftsmanship_gate',{}).get('status')!='PASS':return fail('craftsmanship not PASS')
    ac=r.get('anti_confabulation_gate',{})
    if ac.get('status')!='PASS' or ac.get('blocked_claims'):return fail('anti-confabulation blocked')
    s=r.get('anti_sycophancy',{});score=s.get('score');th=s.get('threshold',3)
    if not isinstance(score,int) or score>=th:return fail('anti-sycophancy threshold')
    if r.get('bias_gate',{}).get('status')=='BLOCKED':return fail('bias gate blocked')
    if not r.get('artifact_digest'):return fail('artifact_digest missing')
    print('PASS: release gate');return 0
if __name__=='__main__':raise SystemExit(main(sys.argv))
